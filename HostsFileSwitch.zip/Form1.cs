﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HostsFileSwitch
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        const string HOSTSFILEPATH = @"C:\Windows\System32\drivers\etc\hosts";


        private void Form1_Load(object sender, EventArgs e)
        {
            string fileContent = File.ReadAllText(HOSTSFILEPATH);
            txtFileContent.Text = fileContent;

            var contentList = fileContent.Split(new string[] { "\r\n" }, StringSplitOptions.None).Reverse();
            //排除掉以# 号开头的数据
            var enabledList = contentList.Where(o => !o.StartsWith("#"));
            //排除掉另外一部分数据
            var disabledList = contentList.Except(enabledList);

            lbEnabled.Items.AddRange(enabledList.ToArray());
            lbDisabled.Items.AddRange(disabledList.ToArray());

        }


        private void Save(string[] allList)
        {
            try
            {
                if (File.Exists(HOSTSFILEPATH))
                {
                    File.Delete(HOSTSFILEPATH);
                }

                File.AppendAllLines(HOSTSFILEPATH, allList.ToArray());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void Move_Click(object sender, EventArgs e)
        {
            var btn = (Button)sender;


            switch (btn.Text)
            {
                case ">>":
                    var swapList = lbEnabled.Items.Cast<string>();
                    var targetList = swapList.Cast<string>().Select(o => "#" + o);
                    lbDisabled.Items.AddRange(targetList.ToArray());
                    lbEnabled.Items.Remove(swapList);

                    break;
                case ">":
                    swapList = lbEnabled.SelectedItems.Cast<string>();
                    targetList = swapList.Cast<string>().Select(o => "#" + o);
                    lbDisabled.Items.AddRange(targetList.ToArray());
                    lbEnabled.Items.Remove(swapList);
                    break;



                case "<<":
                    swapList = lbDisabled.Items.Cast<string>();
                    targetList = swapList.Cast<string>().Select(o => o.TrimStart(" #".ToCharArray()));
                    lbEnabled.Items.AddRange(targetList.ToArray());
                    lbDisabled.Items.Remove(swapList);

                    break;

                case "<":
                    swapList = lbDisabled.SelectedItems.Cast<string>();
                    targetList = swapList.Cast<string>().Select(o => o.TrimStart(" #".ToCharArray()));
                    lbEnabled.Items.AddRange(targetList.ToArray());
                    lbDisabled.Items.Remove(swapList);
                    break;

                default:
                    break;
            }



            var lsEnabled = lbEnabled.Items.Cast<string>();
            var lsDisabled = lbDisabled.Items.Cast<string>();

            var allList = new List<string>();


            allList.AddRange(lsEnabled);
            allList.AddRange(lsDisabled);
            allList.Reverse();

            Save(allList.ToArray());
        }
    }
}
